
import 'package:flutter/material.dart';

void main() => runApp(const AdminApp());

class AdminApp extends StatelessWidget {
  const AdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'الهام یاسر | مدیریت',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF071A33),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFD9A441),
          brightness: Brightness.dark,
        ),
      ),
      home: const AdminDashboard(),
    );
  }
}

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int selected = 0;

  final menu = const [
    ('🏠', 'داشبورد'),
    ('🌍', 'کشورها'),
    ('🛂', 'انواع ویزه'),
    ('📋', 'شرایط و مدارک'),
    ('🔗', 'سایت‌های رسمی'),
    ('💰', 'قیمت‌ها'),
    ('👥', 'کاربران'),
    ('📝', 'درخواست‌ها'),
    ('⚙️', 'تنظیمات'),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('الهام یاسر • پنل مدیریت',
              style: TextStyle(fontWeight: FontWeight.w900)),
          actions: [
            IconButton(
              tooltip: 'اعلان‌ها',
              onPressed: () {},
              icon: const Icon(Icons.notifications_none_rounded),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 12),
              child: Center(
                child: Text('مدیر اصلی',
                    style: TextStyle(color: Color(0xFFD9A441))),
              ),
            ),
          ],
        ),
        body: Row(
          children: [
            NavigationRail(
              selectedIndex: selected,
              onDestinationSelected: (i) => setState(() => selected = i),
              labelType: NavigationRailLabelType.all,
              destinations: [
                for (final item in menu)
                  NavigationRailDestination(
                    icon: Text(item.$1, style: const TextStyle(fontSize: 20)),
                    label: Text(item.$2),
                  ),
              ],
            ),
            const VerticalDivider(width: 1),
            Expanded(child: _content()),
          ],
        ),
      ),
    );
  }

  Widget _content() {
    switch (selected) {
      case 1:
        return const CountryManagement();
      case 2:
        return const VisaManagement();
      case 3:
        return const RequirementsManagement();
      case 4:
        return const OfficialLinksManagement();
      case 5:
        return const PricingManagement();
      default:
        return const Overview();
    }
  }
}

class Overview extends StatelessWidget {
  const Overview({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        const Text('داشبورد مدیریتی',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
        const SizedBox(height: 18),
        Wrap(
          spacing: 14,
          runSpacing: 14,
          children: [
            _stat('کشورها', '24'),
            _stat('انواع ویزه', '61'),
            _stat('درخواست‌های جدید', '18'),
            _stat('لینک‌های نیازمند بررسی', '7'),
          ],
        ),
        const SizedBox(height: 28),
        Card(
          child: ListTile(
            leading: const Icon(Icons.verified_outlined,
                color: Color(0xFFD9A441)),
            title: const Text('کنترل منابع رسمی'),
            subtitle: const Text(
              'مدیر می‌تواند لینک‌های درخواست، سفارت، مهاجرت، وقت، پیگیری و هزینه را بررسی و به‌روزرسانی کند.',
            ),
          ),
        ),
      ],
    );
  }

  static Widget _stat(String title, String value) => SizedBox(
        width: 190,
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title),
                const SizedBox(height: 10),
                Text(value,
                    style: const TextStyle(
                        fontSize: 28, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
        ),
      );
}

class CountryManagement extends StatelessWidget {
  const CountryManagement({super.key});

  @override
  Widget build(BuildContext context) {
    return _managementPage(
      context,
      title: 'مدیریت کشورها',
      addLabel: 'افزودن کشور',
      columns: const ['کشور', 'کد', 'وضعیت', 'عملیات'],
      rows: const [
        ['🇦🇪 امارات متحده عربی', 'AE', 'فعال'],
        ['🇹🇷 ترکیه', 'TR', 'فعال'],
        ['🇬🇧 انگلستان', 'GB', 'فعال'],
        ['🇺🇸 ایالات متحده', 'US', 'فعال'],
      ],
    );
  }
}

class VisaManagement extends StatelessWidget {
  const VisaManagement({super.key});

  @override
  Widget build(BuildContext context) {
    return _managementPage(
      context,
      title: 'مدیریت انواع ویزه',
      addLabel: 'افزودن ویزه',
      columns: const ['کشور', 'نوع ویزه', 'هزینه', 'وضعیت', 'عملیات'],
      rows: const [
        ['🇬🇧 انگلستان', 'توریستی', '—', 'فعال'],
        ['🇦🇪 امارات', 'توریستی', '—', 'فعال'],
        ['🇹🇷 ترکیه', 'تجاری', '—', 'فعال'],
      ],
    );
  }
}

class RequirementsManagement extends StatelessWidget {
  const RequirementsManagement({super.key});

  @override
  Widget build(BuildContext context) {
    return _managementPage(
      context,
      title: 'شرایط و مدارک',
      addLabel: 'افزودن مورد',
      columns: const ['کشور', 'نوع ویزه', 'شرایط', 'مدارک', 'عملیات'],
      rows: const [
        ['انگلستان', 'توریستی', 'قابل ویرایش', 'پاسپورت، عکس، مدارک مالی', ''],
        ['امارات', 'توریستی', 'قابل ویرایش', 'پاسپورت، عکس', ''],
      ],
    );
  }
}

class OfficialLinksManagement extends StatelessWidget {
  const OfficialLinksManagement({super.key});

  @override
  Widget build(BuildContext context) {
    return _managementPage(
      context,
      title: 'سایت‌های رسمی ویزه',
      addLabel: 'افزودن سایت رسمی',
      columns: const [
        'کشور',
        'نوع لینک',
        'عنوان',
        'URL',
        'آخرین بررسی',
        'وضعیت',
        'عملیات'
      ],
      rows: const [
        [
          'امارات',
          'درخواست ویزه',
          'Official Visa',
          'ثبت URL رسمی',
          '—',
          'فعال'
        ],
        [
          'انگلستان',
          'راهنمای رسمی',
          'Visa Guidance',
          'ثبت URL رسمی',
          '—',
          'فعال'
        ],
      ],
    );
  }
}

class PricingManagement extends StatelessWidget {
  const PricingManagement({super.key});

  @override
  Widget build(BuildContext context) {
    return _managementPage(
      context,
      title: 'مدیریت قیمت‌ها',
      addLabel: 'افزودن قیمت',
      columns: const ['خدمت', 'کشور', 'قیمت', 'ارز', 'آخرین تغییر', 'عملیات'],
      rows: const [
        ['ویزه توریستی', 'امارات', '—', 'USD', '—'],
        ['خدمت اپلای', '—', '—', 'AFN', '—'],
      ],
    );
  }
}

Widget _managementPage(
  BuildContext context, {
  required String title,
  required String addLabel,
  required List<String> columns,
  required List<List<String>> rows,
}) {
  return ListView(
    padding: const EdgeInsets.all(24),
    children: [
      Row(
        children: [
          Expanded(
            child: Text(title,
                style:
                    const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          ),
          FilledButton.icon(
            onPressed: () => _showEditor(context, title),
            icon: const Icon(Icons.add),
            label: Text(addLabel),
          ),
        ],
      ),
      const SizedBox(height: 18),
      Card(
        clipBehavior: Clip.antiAlias,
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columns: [
              for (final c in columns) DataColumn(label: Text(c)),
              const DataColumn(label: Text('')),
            ],
            rows: [
              for (final row in rows)
                DataRow(
                  cells: [
                    for (final value in row) DataCell(Text(value)),
                    DataCell(
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            tooltip: 'ویرایش',
                            onPressed: () => _showEditor(context, title),
                            icon: const Icon(Icons.edit_outlined),
                          ),
                          IconButton(
                            tooltip: 'حذف',
                            onPressed: () => _confirmDelete(context),
                            icon: const Icon(Icons.delete_outline),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    ],
  );
}

void _showEditor(BuildContext context, String section) {
  final controller = TextEditingController();
  showDialog(
    context: context,
    builder: (_) => AlertDialog(
      title: Text('افزودن / ویرایش • $section'),
      content: SizedBox(
        width: 520,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: controller,
              decoration: const InputDecoration(
                labelText: 'نام یا عنوان',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            const TextField(
              decoration: InputDecoration(
                labelText: 'توضیحات / شرایط / URL',
                border: OutlineInputBorder(),
              ),
              maxLines: 4,
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('انصراف'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('ذخیره'),
        ),
      ],
    ),
  );
}

void _confirmDelete(BuildContext context) {
  showDialog(
    context: context,
    builder: (_) => AlertDialog(
      title: const Text('حذف مورد'),
      content: const Text('آیا از حذف این مورد مطمئن هستید؟'),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('انصراف'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('حذف'),
        ),
      ],
    ),
  );
}
