
-- Add this to the existing Supabase schema.

alter table if exists official_visa_links
  add column if not exists sort_order int not null default 0;

-- Recommended production protections:
-- 1) Enable RLS on all tables.
-- 2) Only admin/manager roles can INSERT/UPDATE/DELETE countries, visas,
--    requirements, prices and official links.
-- 3) Customers can SELECT only active public visa data and their own applications.
-- 4) Passport/document storage must use a PRIVATE bucket and signed URLs.
-- 5) Every admin mutation should insert an audit_logs record.
