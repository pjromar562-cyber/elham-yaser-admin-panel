import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = 'https://vcecjetxieumugzhamsi.supabase.co';
// Paste your Supabase publishable key here if it is not already configured.
const supabasePublishableKey = 'PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE';

final supabase = Supabase.instance.client;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: supabaseUrl,
    publishableKey: supabasePublishableKey,
  );
  runApp(const ElhamYaserApp());
}

class ElhamYaserApp extends StatelessWidget {
  const ElhamYaserApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'الهام یاسر | پنل مدیریت',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0B2A4A)),
        scaffoldBackgroundColor: const Color(0xFFF4F7FA),
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: supabase.auth.onAuthStateChange,
      builder: (context, snap) {
        if (supabase.auth.currentSession == null) return const LoginPage();
        return const AdminShell();
      },
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;
  String? error;

  Future<void> login() async {
    setState(() { loading = true; error = null; });
    try {
      await supabase.auth.signInWithPassword(
        email: email.text.trim(),
        password: password.text,
      );
    } on AuthException catch (e) {
      setState(() => error = e.message);
    } catch (e) {
      setState(() => error = 'خطا در ورود: $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 430),
            child: Card(
              elevation: 8,
              margin: const EdgeInsets.all(24),
              child: Padding(
                padding: const EdgeInsets.all(28),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const CircleAvatar(
                      radius: 38,
                      backgroundColor: Color(0xFF0B2A4A),
                      child: Icon(Icons.flight_takeoff, color: Colors.white, size: 38),
                    ),
                    const SizedBox(height: 16),
                    const Text('الهام یاسر', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
                    const Text('پنل مدیریت سفر و ویزه', style: TextStyle(color: Colors.grey)),
                    const SizedBox(height: 28),
                    TextField(controller: email, keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(labelText: 'ایمیل مدیر', prefixIcon: Icon(Icons.email_outlined), border: OutlineInputBorder())),
                    const SizedBox(height: 14),
                    TextField(controller: password, obscureText: true,
                      decoration: const InputDecoration(labelText: 'رمز عبور', prefixIcon: Icon(Icons.lock_outline), border: OutlineInputBorder())),
                    if (error != null) ...[
                      const SizedBox(height: 12),
                      Text(error!, style: const TextStyle(color: Colors.red)),
                    ],
                    const SizedBox(height: 20),
                    SizedBox(width: double.infinity, height: 50,
                      child: FilledButton(onPressed: loading ? null : login,
                        child: loading ? const CircularProgressIndicator() : const Text('ورود به پنل'))),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class AdminShell extends StatefulWidget {
  const AdminShell({super.key});
  @override State<AdminShell> createState() => _AdminShellState();
}
class _AdminShellState extends State<AdminShell> {
  int index = 0;
  final pages = const [
    DashboardPage(), CountriesPage(), VisasPage(), RequirementsPage(),
    LinksPage(), PricesPage(), ApplicationsPage()
  ];
  final titles = ['داشبورد','کشورها','ویزه‌ها','شرایط و مدارک','سایت‌های رسمی','قیمت‌ها','درخواست‌ها'];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('الهام یاسر — ${titles[index]}', style: const TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            IconButton(tooltip: 'خروج', onPressed: () => supabase.auth.signOut(), icon: const Icon(Icons.logout)),
            const SizedBox(width: 8),
          ],
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              const DrawerHeader(
                decoration: BoxDecoration(color: Color(0xFF0B2A4A)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(Icons.travel_explore, color: Colors.white, size: 42),
                  SizedBox(height: 10),
                  Text('الهام یاسر', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                  Text('مدیریت سفر و ویزه', style: TextStyle(color: Colors.white70)),
                ]),
              ),
              for (int i=0;i<titles.length;i++)
                ListTile(
                  selected: index == i,
                  leading: Icon([Icons.dashboard,Icons.public,Icons.badge,Icons.description,Icons.link,Icons.payments,Icons.assignment][i]),
                  title: Text(titles[i]),
                  onTap: () { setState(() => index = i); Navigator.pop(context); },
                ),
            ],
          ),
        ),
        body: pages[index],
      ),
    );
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override State<DashboardPage> createState() => _DashboardPageState();
}
class _DashboardPageState extends State<DashboardPage> {
  Future<int> count(String table) async {
    final r = await supabase.from(table).select('id');
    return (r as List).length;
  }
  @override
  Widget build(BuildContext context) {
    final cards = [
      ('کشورها','countries',Icons.public),
      ('ویزه‌ها','visas',Icons.badge),
      ('قیمت‌ها','prices',Icons.payments),
      ('درخواست‌ها','visa_applications',Icons.assignment),
    ];
    return RefreshIndicator(
      onRefresh: () async => setState(() {}),
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('خوش آمدید 👋', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text('مدیریت محتوای ویزه، کشورها، قیمت‌ها و درخواست‌های مشتریان'),
          const SizedBox(height: 20),
          GridView.builder(
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 260, mainAxisExtent: 130, crossAxisSpacing: 14, mainAxisSpacing: 14),
            itemCount: cards.length,
            itemBuilder: (_, i) => FutureBuilder<int>(
              future: count(cards[i].$2),
              builder: (_, s) => Card(
                child: Padding(padding: const EdgeInsets.all(18), child: Row(children: [
                  CircleAvatar(radius: 28, child: Icon(cards[i].$3)),
                  const SizedBox(width: 14),
                  Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(cards[i].$1, style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text(s.hasData ? '${s.data}' : '...', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                  ]),
                ])),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CountriesPage extends StatelessWidget {
  const CountriesPage({super.key});
  @override Widget build(BuildContext context) => CrudPage(
    title: 'کشورها', table: 'countries',
    columns: const ['name','code','is_active'],
    labels: const {'name':'نام کشور','code':'کد کشور','is_active':'فعال'},
    fields: const ['name','code'],
  );
}
class VisasPage extends StatelessWidget {
  const VisasPage({super.key});
  @override Widget build(BuildContext context) => CrudPage(
    title: 'ویزه‌ها', table: 'visas',
    columns: const ['id','country_id','name','processing_days','is_active'],
    labels: const {'id':'شناسه','country_id':'شناسه کشور','name':'نام ویزه','processing_days':'روز بررسی','is_active':'فعال'},
    fields: const ['country_id','name','processing_days'],
  );
}
class RequirementsPage extends StatelessWidget {
  const RequirementsPage({super.key});
  @override Widget build(BuildContext context) => CrudPage(
    title: 'شرایط و مدارک', table: 'visa_requirements',
    columns: const ['id','visa_id','title','conditions','documents'],
    labels: const {'id':'شناسه','visa_id':'شناسه ویزه','title':'عنوان','conditions':'شرایط','documents':'مدارک'},
    fields: const ['visa_id','title','conditions','documents'],
  );
}
class LinksPage extends StatelessWidget {
  const LinksPage({super.key});
  @override Widget build(BuildContext context) => CrudPage(
    title: 'سایت‌های رسمی', table: 'official_visa_links',
    columns: const ['id','country_id','link_type','title','url','is_active'],
    labels: const {'id':'شناسه','country_id':'کشور','link_type':'نوع','title':'عنوان','url':'لینک','is_active':'فعال'},
    fields: const ['country_id','link_type','title','url'],
  );
}
class PricesPage extends StatelessWidget {
  const PricesPage({super.key});
  @override Widget build(BuildContext context) => CrudPage(
    title: 'قیمت‌ها', table: 'prices',
    columns: const ['id','service_name','country_id','visa_id','amount','currency','is_active'],
    labels: const {'id':'شناسه','service_name':'خدمت','country_id':'کشور','visa_id':'ویزه','amount':'مبلغ','currency':'ارز','is_active':'فعال'},
    fields: const ['service_name','country_id','visa_id','amount','currency'],
  );
}
class ApplicationsPage extends StatelessWidget {
  const ApplicationsPage({super.key});
  @override Widget build(BuildContext context) => CrudPage(
    title: 'درخواست‌های ویزه', table: 'visa_applications',
    columns: const ['id','full_name','phone','country_name','visa_type','status','created_at'],
    labels: const {'id':'شناسه','full_name':'نام مشتری','phone':'تماس','country_name':'کشور','visa_type':'نوع ویزه','status':'وضعیت','created_at':'تاریخ'},
    fields: const ['full_name','phone','country_name','visa_type','status'],
  );
}

class CrudPage extends StatefulWidget {
  final String title, table;
  final List<String> columns, fields;
  final Map<String,String> labels;
  const CrudPage({super.key, required this.title, required this.table, required this.columns, required this.labels, required this.fields});
  @override State<CrudPage> createState() => _CrudPageState();
}
class _CrudPageState extends State<CrudPage> {
  bool loading = true;
  List<Map<String,dynamic>> rows = [];
  String? error;

  @override void initState(){super.initState(); load();}
  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final data = await supabase.from(widget.table).select().order('id', ascending: false);
      rows = List<Map<String,dynamic>>.from(data);
    } catch(e) { error = e.toString(); }
    if(mounted) setState(() => loading = false);
  }

  Future<void> remove(dynamic id) async {
    try {
      await supabase.from(widget.table).delete().eq('id', id);
      await load();
    } catch(e) {
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('حذف نشد: $e')));
    }
  }

  Future<void> edit(Map<String,dynamic>? row) async {
    final controllers = { for (final f in widget.fields) f: TextEditingController(text: '${row?[f] ?? ''}') };
    final ok = await showDialog<bool>(context: context, builder: (_) => Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: Text(row == null ? 'افزودن ${widget.title}' : 'ویرایش ${widget.title}'),
        content: SizedBox(width: 500, child: SingleChildScrollView(child: Column(
          mainAxisSize: MainAxisSize.min,
          children: widget.fields.map((f) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: TextField(controller: controllers[f], decoration: InputDecoration(labelText: widget.labels[f] ?? f, border: const OutlineInputBorder())),
          )).toList(),
        ))),
        actions: [
          TextButton(onPressed: ()=>Navigator.pop(context,false), child: const Text('انصراف')),
          FilledButton(onPressed: () async {
            try {
              final payload = <String,dynamic>{};
              for(final f in widget.fields){
                final v = controllers[f]!.text.trim();
                if (f.contains('id') || f == 'processing_days' || f == 'amount') {
                  payload[f] = num.tryParse(v);
                } else {
                  payload[f] = v;
                }
              }
              if (row == null) {
                await supabase.from(widget.table).insert(payload);
              } else {
                await supabase.from(widget.table).update(payload).eq('id', row['id']);
              }
              if(context.mounted) Navigator.pop(context,true);
            } catch(e) {
              if(context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('ذخیره نشد: $e')));
            }
          }, child: const Text('ذخیره')),
        ],
      ),
    ));
    for(final c in controllers.values) c.dispose();
    if(ok == true) load();
  }

  @override Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Text(widget.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Spacer(),
          IconButton(onPressed: load, icon: const Icon(Icons.refresh)),
          FilledButton.icon(onPressed: ()=>edit(null), icon: const Icon(Icons.add), label: const Text('افزودن')),
        ]),
        const SizedBox(height: 12),
        if(error != null) Padding(padding: const EdgeInsets.all(12), child: Text(error!, style: const TextStyle(color: Colors.red))),
        Expanded(child: loading ? const Center(child: CircularProgressIndicator()) : rows.isEmpty
          ? const Center(child: Text('هنوز اطلاعاتی ثبت نشده است.'))
          : Card(child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: DataTable(
              columns: [
                ...widget.columns.map((c)=>DataColumn(label: Text(widget.labels[c] ?? c))),
                const DataColumn(label: Text('عملیات')),
              ],
              rows: rows.map((r)=>DataRow(cells: [
                ...widget.columns.map((c)=>DataCell(Text(formatValue(c,r[c])))),
                DataCell(Row(mainAxisSize: MainAxisSize.min, children: [
                  IconButton(onPressed: ()=>edit(r), icon: const Icon(Icons.edit_outlined)),
                  IconButton(onPressed: ()=>confirmDelete(r['id']), icon: const Icon(Icons.delete_outline, color: Colors.red)),
                ])),
              ])).toList(),
            ))),
      ]),
    );
  }
  String formatValue(String c, dynamic v) {
    if(v == null) return '-';
    if(c == 'created_at') {
      try { return DateFormat('yyyy/MM/dd HH:mm').format(DateTime.parse(v.toString()).toLocal()); } catch(_){}
    }
    if(v is bool) return v ? 'بله' : 'خیر';
    return v.toString();
  }
  Future<void> confirmDelete(dynamic id) async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('حذف اطلاعات'),
      content: const Text('آیا از حذف این مورد مطمئن هستید؟'),
      actions: [
        TextButton(onPressed: ()=>Navigator.pop(context,false), child: const Text('انصراف')),
        FilledButton(onPressed: ()=>Navigator.pop(context,true), child: const Text('حذف')),
      ],
    ));
    if(ok == true) remove(id);
  }
}
