# Elham Yaser Admin Panel — REAL SUPABASE

Flutter admin panel for managing countries, visas, visa requirements/documents,
official visa links, prices, and visa applications.

## 1. Supabase
Run `supabase/admin_additions.sql` once in the Supabase SQL Editor.
The SQL creates the tables, RLS policies, and registers the manager account.

## 2. Supabase publishable key
Open `lib/main.dart` and replace:
PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE

with your Supabase **publishable key**.

Do not put a service_role/secret key in Flutter or GitHub.

## 3. Run
flutter pub get
flutter run -d chrome

## 4. GitHub
For GitHub Pages, build the Flutter web app with:
flutter build web --release --base-href "/elham-yaser-admin-panel/"

Then publish the generated `build/web` directory using GitHub Pages or another static host.

## Important
This version is a functional starter admin panel. It requires the Supabase SQL to be run first
and the manager account to exist in Supabase Auth.
