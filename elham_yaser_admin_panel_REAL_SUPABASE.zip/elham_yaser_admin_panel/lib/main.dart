import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = 'https://vcecjetxieumugzhamsi.supabase.co';
const supabasePublishableKey = 'sb_publishable_XYCQ2hAVT12mm2IePMmHrQ_bAzW8G1f';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabasePublishableKey);
  runApp(const AdminApp());
}

final supabase = Supabase.instance.client;

class AdminApp extends StatelessWidget {
  const AdminApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'الهام یاسر | مدیریت',
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF071A33),
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFD9A441), brightness: Brightness.dark),
          inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
        ),
        home: const AuthGate(),
      );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: supabase.auth.onAuthStateChange,
      builder: (_, snapshot) {
        final session = snapshot.data?.session ?? supabase.auth.currentSession;
        return session == null ? const LoginPage() : const AdminDashboard();
      },
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;
  String? error;

  Future<void> login() async {
    setState(() { loading = true; error = null; });
    try {
      await supabase.auth.signInWithPassword(email: email.text.trim(), password: password.text);
    } on AuthException catch (e) {
      setState(() => error = e.message);
    } catch (e) {
      setState(() => error = 'خطا در اتصال: $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          body: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 430),
              child: Card(
                margin: const EdgeInsets.all(24),
                child: Padding(
                  padding: const EdgeInsets.all(28),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.travel_explore, size: 64, color: Color(0xFFD9A441)),
                    const SizedBox(height: 12),
                    const Text('الهام یاسر', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 4),
                    const Text('ورود به پنل مدیریت'),
                    const SizedBox(height: 24),
                    TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'ایمیل مدیر')),
                    const SizedBox(height: 14),
                    TextField(controller: password, obscureText: true, onSubmitted: (_) => login(), decoration: const InputDecoration(labelText: 'رمز عبور')),
                    if (error != null) ...[
                      const SizedBox(height: 12),
                      Text(error!, style: const TextStyle(color: Colors.redAccent)),
                    ],
                    const SizedBox(height: 20),
                    SizedBox(width: double.infinity, child: FilledButton.icon(
                      onPressed: loading ? null : login,
                      icon: loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.login),
                      label: Text(loading ? 'در حال ورود...' : 'ورود'),
                    )),
                  ]),
                ),
              ),
            ),
          ),
        ),
      );
}

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});
  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int selected = 0;
  final menu = const [
    ('🏠', 'داشبورد'), ('🌍', 'کشورها'), ('🛂', 'انواع ویزه'), ('📋', 'شرایط و مدارک'),
    ('🔗', 'سایت‌های رسمی'), ('💰', 'قیمت‌ها'), ('👥', 'کاربران'), ('📝', 'درخواست‌ها'),
  ];

  Widget content() {
    switch (selected) {
      case 1: return const CountriesPage();
      case 2: return const VisasPage();
      case 3: return const RequirementsPage();
      case 4: return const OfficialLinksPage();
      case 5: return const PricesPage();
      case 6: return const UsersPage();
      case 7: return const ApplicationsPage();
      default: return const OverviewPage();
    }
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('الهام یاسر • پنل مدیریت', style: TextStyle(fontWeight: FontWeight.w900)),
            actions: [
              IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded)),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Center(child: Text('مدیر اصلی', style: TextStyle(color: Color(0xFFD9A441))))),
              IconButton(tooltip: 'خروج', onPressed: () => supabase.auth.signOut(), icon: const Icon(Icons.logout)),
            ],
          ),
          body: Row(children: [
            NavigationRail(
              selectedIndex: selected,
              onDestinationSelected: (i) => setState(() => selected = i),
              labelType: NavigationRailLabelType.all,
              destinations: [for (final item in menu) NavigationRailDestination(icon: Text(item.$1, style: const TextStyle(fontSize: 20)), label: Text(item.$2))],
            ),
            const VerticalDivider(width: 1),
            Expanded(child: content()),
          ]),
        ),
      );
}

class OverviewPage extends StatelessWidget {
  const OverviewPage({super.key});
  Future<int> count(String table) async => (await supabase.from(table).select('id')).length;
  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const Text('داشبورد مدیریتی', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
          const SizedBox(height: 18),
          Wrap(spacing: 14, runSpacing: 14, children: [
            _LiveStat(title: 'کشورها', table: 'countries', icon: Icons.public),
            _LiveStat(title: 'انواع ویزه', table: 'visas', icon: Icons.badge_outlined),
            _LiveStat(title: 'قیمت‌ها', table: 'prices', icon: Icons.payments_outlined),
            _LiveStat(title: 'درخواست‌ها', table: 'visa_applications', icon: Icons.description_outlined),
          ]),
          const SizedBox(height: 28),
          Card(child: ListTile(leading: const Icon(Icons.cloud_done_outlined, color: Color(0xFFD9A441)), title: const Text('اتصال Supabase فعال است'), subtitle: Text('پروژه: $supabaseUrl'))),
          const SizedBox(height: 12),
          const Card(child: ListTile(leading: Icon(Icons.security_outlined), title: Text('امنیت'), subtitle: Text('ورود مدیر با Supabase Auth انجام می‌شود و دسترسی داده‌ها با RLS کنترل می‌شود.'))),
        ],
      );
}

class _LiveStat extends StatelessWidget {
  final String title, table; final IconData icon;
  const _LiveStat({required this.title, required this.table, required this.icon});
  @override
  Widget build(BuildContext context) => FutureBuilder<List<Map<String, dynamic>>>(
        future: supabase.from(table).select('id'),
        builder: (_, snap) => SizedBox(width: 205, child: Card(child: Padding(padding: const EdgeInsets.all(20), child: Row(children: [Icon(icon, color: const Color(0xFFD9A441)), const SizedBox(width: 12), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title), const SizedBox(height: 6), Text('${snap.data?.length ?? 0}', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900))])]))),
      );
}

abstract class CrudPage extends StatefulWidget { const CrudPage({super.key}); }

class CountriesPage extends StatefulWidget { const CountriesPage({super.key}); @override State<CountriesPage> createState() => _CountriesPageState(); }
class _CountriesPageState extends State<CountriesPage> {
  bool loading = true; List<Map<String,dynamic>> rows = [];
  Future<void> load() async { setState(() => loading = true); rows = await supabase.from('countries').select().order('name'); if (mounted) setState(() => loading = false); }
  @override void initState(){super.initState(); load();}
  Future<void> edit([Map<String,dynamic>? row]) async { final result = await showCountryDialog(context, row); if(result == null) return; if(row == null){await supabase.from('countries').insert(result);}else{await supabase.from('countries').update(result).eq('id', row['id']);} load(); }
  Future<void> remove(Map<String,dynamic> row) async { if(await confirm(context)){await supabase.from('countries').delete().eq('id', row['id']); load();} }
  @override Widget build(BuildContext context) => CrudScaffold(title:'مدیریت کشورها', add:'افزودن کشور', loading:loading, onAdd:()=>edit(), headers:const['کشور','کد','وضعیت','عملیات'], rows:[for(final r in rows)[r['name']??'',r['code']??'',r['is_active']==true?'فعال':'غیرفعال',_actions(()=>edit(r),()=>remove(r))]]);
}

class VisasPage extends StatefulWidget { const VisasPage({super.key}); @override State<VisasPage> createState()=>_VisasPageState(); }
class _VisasPageState extends State<VisasPage>{ bool loading=true; List<Map<String,dynamic>> rows=[]; List<Map<String,dynamic>> countries=[];
 Future<void> load() async {setState(()=>loading=true); countries=await supabase.from('countries').select().order('name'); rows=await supabase.from('visas').select().order('name'); if(mounted)setState(()=>loading=false);}
 @override void initState(){super.initState();load();}
 Future<void> edit([Map<String,dynamic>? row])async{final result=await showVisaDialog(context,row,countries);if(result==null)return;if(row==null)await supabase.from('visas').insert(result);else await supabase.from('visas').update(result).eq('id',row['id']);load();}
 Future<void> remove(Map<String,dynamic> row)async{if(await confirm(context)){await supabase.from('visas').delete().eq('id',row['id']);load();}}
 String country(dynamic id)=>countries.firstWhere((c)=>c['id']==id,orElse:()=>{'name':'—'})['name'];
 @override Widget build(BuildContext c)=>CrudScaffold(title:'مدیریت انواع ویزه',add:'افزودن ویزه',loading:loading,onAdd:()=>edit(),headers:const['کشور','نوع ویزه','مدت بررسی','وضعیت','عملیات'],rows:[for(final r in rows)[country(r['country_id']),r['name']??'',r['processing_days']??'—',r['is_active']==true?'فعال':'غیرفعال',_actions(()=>edit(r),()=>remove(r))]]);
}

class RequirementsPage extends StatefulWidget { const RequirementsPage({super.key}); @override State<RequirementsPage> createState()=>_RequirementsPageState(); }
class _RequirementsPageState extends State<RequirementsPage>{bool loading=true;List<Map<String,dynamic>> rows=[];List<Map<String,dynamic>> visas=[];
 Future<void> load()async{setState(()=>loading=true);visas=await supabase.from('visas').select().order('name');rows=await supabase.from('visa_requirements').select().order('title');if(mounted)setState(()=>loading=false);}
 @override void initState(){super.initState();load();}
 Future<void> edit([Map<String,dynamic>? row])async{final result=await showRequirementDialog(context,row,visas);if(result==null)return;if(row==null)await supabase.from('visa_requirements').insert(result);else await supabase.from('visa_requirements').update(result).eq('id',row['id']);load();}
 Future<void> remove(Map<String,dynamic> row)async{if(await confirm(context)){await supabase.from('visa_requirements').delete().eq('id',row['id']);load();}}
 String visa(dynamic id)=>visas.firstWhere((v)=>v['id']==id,orElse:()=>{'name':'—'})['name'];
 @override Widget build(BuildContext c)=>CrudScaffold(title:'شرایط و مدارک',add:'افزودن مورد',loading:loading,onAdd:()=>edit(),headers:const['ویزہ','عنوان','شرایط','مدارک','عملیات'],rows:[for(final r in rows)[visa(r['visa_id']),r['title']??'',r['conditions']??'',r['documents']??'',_actions(()=>edit(r),()=>remove(r))]]);
}

class OfficialLinksPage extends StatefulWidget { const OfficialLinksPage({super.key}); @override State<OfficialLinksPage> createState()=>_OfficialLinksPageState(); }
class _OfficialLinksPageState extends State<OfficialLinksPage>{bool loading=true;List<Map<String,dynamic>> rows=[];List<Map<String,dynamic>> countries=[];
 Future<void> load()async{setState(()=>loading=true);countries=await supabase.from('countries').select().order('name');rows=await supabase.from('official_visa_links').select().order('sort_order').order('title');if(mounted)setState(()=>loading=false);}
 @override void initState(){super.initState();load();}
 Future<void> edit([Map<String,dynamic>? row])async{final result=await showLinkDialog(context,row,countries);if(result==null)return;if(row==null)await supabase.from('official_visa_links').insert(result);else await supabase.from('official_visa_links').update(result).eq('id',row['id']);load();}
 Future<void> remove(Map<String,dynamic> row)async{if(await confirm(context)){await supabase.from('official_visa_links').delete().eq('id',row['id']);load();}}
 String country(dynamic id)=>countries.firstWhere((c)=>c['id']==id,orElse:()=>{'name':'—'})['name'];
 @override Widget build(BuildContext c)=>CrudScaffold(title:'سایت‌های رسمی ویزه',add:'افزودن سایت رسمی',loading:loading,onAdd:()=>edit(),headers:const['کشور','نوع لینک','عنوان','URL','وضعیت','عملیات'],rows:[for(final r in rows)[country(r['country_id']),r['link_type']??'',r['title']??'',r['url']??'',r['is_active']==true?'فعال':'غیرفعال',_actions(()=>edit(r),()=>remove(r))]]);
}

class PricesPage extends StatefulWidget { const PricesPage({super.key}); @override State<PricesPage> createState()=>_PricesPageState(); }
class _PricesPageState extends State<PricesPage>{bool loading=true;List<Map<String,dynamic>> rows=[];List<Map<String,dynamic>> countries=[];List<Map<String,dynamic>> visas=[];
 Future<void> load()async{setState(()=>loading=true);countries=await supabase.from('countries').select().order('name');visas=await supabase.from('visas').select().order('name');rows=await supabase.from('prices').select().order('service_name');if(mounted)setState(()=>loading=false);}
 @override void initState(){super.initState();load();}
 Future<void> edit([Map<String,dynamic>? row])async{final result=await showPriceDialog(context,row,countries,visas);if(result==null)return;if(row==null)await supabase.from('prices').insert(result);else await supabase.from('prices').update(result).eq('id',row['id']);load();}
 Future<void> remove(Map<String,dynamic> row)async{if(await confirm(context)){await supabase.from('prices').delete().eq('id',row['id']);load();}}
 String country(dynamic id)=>countries.firstWhere((c)=>c['id']==id,orElse:()=>{'name':'—'})['name'];
 @override Widget build(BuildContext c)=>CrudScaffold(title:'مدیریت قیمت‌ها',add:'افزودن قیمت',loading:loading,onAdd:()=>edit(),headers:const['خدمت','کشور','قیمت','ارز','وضعیت','عملیات'],rows:[for(final r in rows)[r['service_name']??'',country(r['country_id']),r['amount']?.toString()??'—',r['currency']??'USD',r['is_active']==true?'فعال':'غیرفعال',_actions(()=>edit(r),()=>remove(r))]]);
}

class UsersPage extends StatefulWidget{const UsersPage({super.key});@override State<UsersPage> createState()=>_UsersPageState();}
class _UsersPageState extends State<UsersPage>{bool loading=true;List<Map<String,dynamic>> rows=[];Future<void>load()async{setState(()=>loading=true);rows=await supabase.from('admin_users').select().order('created_at');if(mounted)setState(()=>loading=false);} @override void initState(){super.initState();load();}
 @override Widget build(BuildContext c)=>CrudScaffold(title:'کاربران مدیر',add:'',loading:loading,onAdd:()=>{},headers:const['شناسه کاربر','نقش','وضعیت'],rows:[for(final r in rows)[r['user_id']??'',r['role']??'admin',r['is_active']==true?'فعال':'غیرفعال']]);}

class ApplicationsPage extends StatefulWidget{const ApplicationsPage({super.key});@override State<ApplicationsPage> createState()=>_ApplicationsPageState();}
class _ApplicationsPageState extends State<ApplicationsPage>{bool loading=true;List<Map<String,dynamic>> rows=[];Future<void>load()async{setState(()=>loading=true);rows=await supabase.from('visa_applications').select().order('created_at',ascending:false);if(mounted)setState(()=>loading=false);} @override void initState(){super.initState();load();}
 Future<void>status(Map<String,dynamic> r)async{final value=await showStatusDialog(context,r['status']??'در حال بررسی');if(value!=null){await supabase.from('visa_applications').update({'status':value}).eq('id',r['id']);load();}}
 @override Widget build(BuildContext c)=>CrudScaffold(title:'درخواست‌های ویزه',add:'',loading:loading,onAdd:()=>{},headers:const['متقاضی','شماره تماس','کشور','نوع ویزه','وضعیت','تاریخ'],rows:[for(final r in rows)[r['full_name']??'',r['phone']??'',r['country_name']??'—',r['visa_type']??'—',InkWell(onTap:()=>status(r),child:Chip(label:Text(r['status']??'—'))),_date(r['created_at'])]]);
}

class CrudScaffold extends StatelessWidget{final String title,add;final bool loading;final VoidCallback onAdd;final List<String> headers;final List<List<dynamic>> rows;const CrudScaffold({super.key,required this.title,required this.add,required this.loading,required this.onAdd,required this.headers,required this.rows});
 @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(24),children:[Row(children:[Expanded(child:Text(title,style:const TextStyle(fontSize:28,fontWeight:FontWeight.w900))),if(add.isNotEmpty)FilledButton.icon(onPressed:onAdd,icon:const Icon(Icons.add),label:Text(add)),IconButton(onPressed:()=>{},icon:const Icon(Icons.refresh))]),const SizedBox(height:18),Card(clipBehavior:Clip.antiAlias,child:loading?const Padding(padding:EdgeInsets.all(30),child:Center(child:CircularProgressIndicator())):rows.isEmpty?const Padding(padding:EdgeInsets.all(30),child:Center(child:Text('هنوز موردی ثبت نشده است.'))):SingleChildScrollView(scrollDirection:Axis.horizontal,child:DataTable(columns:[for(final h in headers)DataColumn(label:Text(h))],rows:[for(final row in rows)DataRow(cells:[for(final v in row)DataCell(v is Widget?v:Text(v.toString()))])])))]);
}

Widget _actions(VoidCallback edit, VoidCallback remove)=>Row(mainAxisSize:MainAxisSize.min,children:[IconButton(tooltip:'ویرایش',onPressed:edit,icon:const Icon(Icons.edit_outlined)),IconButton(tooltip:'حذف',onPressed:remove,icon:const Icon(Icons.delete_outline))]);
String _date(dynamic v){if(v==null)return'—';try{return DateTime.parse(v.toString()).toLocal().toString().substring(0,16);}catch(_){return v.toString();}}
Future<bool> confirm(BuildContext c)async=>(await showDialog<bool>(context:c,builder:(_)=>AlertDialog(title:const Text('حذف مورد'),content:const Text('آیا از حذف این مورد مطمئن هستید؟'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('انصراف')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('حذف'))]))??false;

Future<Map<String,dynamic>?> showCountryDialog(BuildContext c,Map<String,dynamic>? row)async{final name=TextEditingController(text:row?['name']??'');final code=TextEditingController(text:row?['code']??'');bool active=row?['is_active']??true;return showDialog<Map<String,dynamic>>(context:c,builder:(_)=>StatefulBuilder(builder:(c,set)=>AlertDialog(title:Text(row==null?'افزودن کشور':'ویرایش کشور'),content:SizedBox(width:500,child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'نام کشور')),const SizedBox(height:12),TextField(controller:code,decoration:const InputDecoration(labelText:'کد دو حرفی')),SwitchListTile(value:active,onChanged:(v)=>set(()=>active=v),title:const Text('فعال')]))),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('انصراف')),FilledButton(onPressed:()=>Navigator.pop(c,{'name':name.text.trim(),'code':code.text.trim().toUpperCase(),'is_active':active}),child:const Text('ذخیره'))])));}

Future<Map<String,dynamic>?> showVisaDialog(BuildContext c,Map<String,dynamic>? row,List<Map<String,dynamic>> countries)async{final name=TextEditingController(text:row?['name']??'');final days=TextEditingController(text:row?['processing_days']?.toString()??'');int? country=row?['country_id'];bool active=row?['is_active']??true;return showDialog<Map<String,dynamic>>(context:c,builder:(_)=>StatefulBuilder(builder:(c,set)=>AlertDialog(title:Text(row==null?'افزودن ویزه':'ویرایش ویزه'),content:SizedBox(width:520,child:Column(mainAxisSize:MainAxisSize.min,children:[DropdownButtonFormField<int>(value:country,items:[for(final x in countries)DropdownMenuItem(value:x['id'] as int,child:Text(x['name']))],onChanged:(v)=>set(()=>country=v),decoration:const InputDecoration(labelText:'کشور')),const SizedBox(height:12),TextField(controller:name,decoration:const InputDecoration(labelText:'نوع ویزه')),const SizedBox(height:12),TextField(controller:days,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'مدت بررسی (روز)')),SwitchListTile(value:active,onChanged:(v)=>set(()=>active=v),title:const Text('فعال'))]))),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('انصراف')),FilledButton(onPressed:country==null?null:()=>Navigator.pop(c,{'country_id':country,'name':name.text.trim(),'processing_days':int.tryParse(days.text),'is_active':active}),child:const Text('ذخیره'))])));}

Future<Map<String,dynamic>?> showRequirementDialog(BuildContext c,Map<String,dynamic>? row,List<Map<String,dynamic>> visas)async{final title=TextEditingController(text:row?['title']??'');final cond=TextEditingController(text:row?['conditions']??'');final docs=TextEditingController(text:row?['documents']??'');int? visa=row?['visa_id'];return showDialog<Map<String,dynamic>>(context:c,builder:(_)=>AlertDialog(title:Text(row==null?'افزودن شرایط':'ویرایش شرایط'),content:SizedBox(width:520,child:Column(mainAxisSize:MainAxisSize.min,children:[DropdownButtonFormField<int>(value:visa,items:[for(final x in visas)DropdownMenuItem(value:x['id'] as int,child:Text(x['name']))],onChanged:(v)=>set(()=>visa=v),decoration:const InputDecoration(labelText:'نوع ویزه')),const SizedBox(height:12),TextField(controller:title,decoration:const InputDecoration(labelText:'عنوان')),const SizedBox(height:12),TextField(controller:cond,maxLines:3,decoration:const InputDecoration(labelText:'شرایط')),const SizedBox(height:12),TextField(controller:docs,maxLines:3,decoration:const InputDecoration(labelText:'مدارک'))])),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('انصراف')),FilledButton(onPressed:visa==null?null:()=>Navigator.pop(c,{'visa_id':visa,'title':title.text.trim(),'conditions':cond.text.trim(),'documents':docs.text.trim()}),child:const Text('ذخیره'))]));}

Future<Map<String,dynamic>?> showLinkDialog(BuildContext c,Map<String,dynamic>? row,List<Map<String,dynamic>> countries)async{final type=TextEditingController(text:row?['link_type']??'درخواست ویزه');final title=TextEditingController(text:row?['title']??'');final url=TextEditingController(text:row?['url']??'');int? country=row?['country_id'];bool active=row?['is_active']??true;final sort=TextEditingController(text:row?['sort_order']?.toString()??'0');return showDialog<Map<String,dynamic>>(context:c,builder:(_)=>StatefulBuilder(builder:(c,set)=>AlertDialog(title:Text(row==null?'افزودن سایت رسمی':'ویرایش سایت رسمی'),content:SizedBox(width:540,child:Column(mainAxisSize:MainAxisSize.min,children:[DropdownButtonFormField<int>(value:country,items:[for(final x in countries)DropdownMenuItem(value:x['id'] as int,child:Text(x['name']))],onChanged:(v)=>set(()=>country=v),decoration:const InputDecoration(labelText:'کشور')),const SizedBox(height:12),TextField(controller:type,decoration:const InputDecoration(labelText:'نوع لینک')),const SizedBox(height:12),TextField(controller:title,decoration:const InputDecoration(labelText:'عنوان')),const SizedBox(height:12),TextField(controller:url,keyboardType:TextInputType.url,decoration:const InputDecoration(labelText:'URL رسمی')),const SizedBox(height:12),TextField(controller:sort,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'ترتیب')),SwitchListTile(value:active,onChanged:(v)=>set(()=>active=v),title:const Text('فعال'))]))),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('انصراف')),FilledButton(onPressed:country==null?null:()=>Navigator.pop(c,{'country_id':country,'link_type':type.text.trim(),'title':title.text.trim(),'url':url.text.trim(),'sort_order':int.tryParse(sort.text)??0,'is_active':active}),child:const Text('ذخیره'))])));}

Future<Map<String,dynamic>?> showPriceDialog(BuildContext c,Map<String,dynamic>? row,List<Map<String,dynamic>> countries,List<Map<String,dynamic>> visas)async{final service=TextEditingController(text:row?['service_name']??'');final amount=TextEditingController(text:row?['amount']?.toString()??'');final currency=TextEditingController(text:row?['currency']??'USD');int? country=row?['country_id'];int? visa=row?['visa_id'];bool active=row?['is_active']??true;return showDialog<Map<String,dynamic>>(context:c,builder:(_)=>StatefulBuilder(builder:(c,set)=>AlertDialog(title:Text(row==null?'افزودن قیمت':'ویرایش قیمت'),content:SizedBox(width:540,child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:service,decoration:const InputDecoration(labelText:'نام خدمت')),const SizedBox(height:12),DropdownButtonFormField<int?>(value:country,items:[const DropdownMenuItem<int?>(value:null,child:Text('همه کشورها')),for(final x in countries)DropdownMenuItem<int?>(value:x['id'] as int,child:Text(x['name']))],onChanged:(v)=>set(()=>country=v),decoration:const InputDecoration(labelText:'کشور')),const SizedBox(height:12),DropdownButtonFormField<int?>(value:visa,items:[const DropdownMenuItem<int?>(value:null,child:Text('بدون ویزه')),for(final x in visas)DropdownMenuItem<int?>(value:x['id'] as int,child:Text(x['name']))],onChanged:(v)=>set(()=>visa=v),decoration:const InputDecoration(labelText:'نوع ویزه')),const SizedBox(height:12),Row(children:[Expanded(child:TextField(controller:amount,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'قیمت'))),const SizedBox(width:10),SizedBox(width:120,child:TextField(controller:currency,decoration:const InputDecoration(labelText:'ارز')))]),SwitchListTile(value:active,onChanged:(v)=>set(()=>active=v),title:const Text('فعال'))]))),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('انصراف')),FilledButton(onPressed:()=>Navigator.pop(c,{'service_name':service.text.trim(),'country_id':country,'visa_id':visa,'amount':double.tryParse(amount.text),'currency':currency.text.trim().toUpperCase(),'is_active':active}),child:const Text('ذخیره'))])));}

Future<String?> showStatusDialog(BuildContext c,String current)async{const options=['در حال بررسی','تأیید شده','رد شده','تکمیل نشده'];return showDialog<String>(context:c,builder:(_)=>SimpleDialog(title:const Text('تغییر وضعیت'),children:[for(final x in options)SimpleDialogOption(onPressed:()=>Navigator.pop(c,x),child:Text(x,style:TextStyle(fontWeight:x==current?FontWeight.bold:FontWeight.normal))) ]));}
